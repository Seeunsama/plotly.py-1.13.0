## plotly.py
##### an interactive, browser-based charting library for python

Plotly for Python is now entirely open source, free, and self-hosted.

[![](https://plot.ly/~chriddyp/1825/.png)](https://plot.ly/~chriddyp/1825.embed)

[![](https://plot.ly/~chriddyp/1780/.png)](https://plot.ly/~chriddyp/1780.embed)

### [Documentation](https://plot.ly/python)

### Contributing

Heck yeah! We've got suggestions! We've got guides!

Checkout [`contributing.md`](https://github.com/plotly/python-api/blob/master/contributing.md).
