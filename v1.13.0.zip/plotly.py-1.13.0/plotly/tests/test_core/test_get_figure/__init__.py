import warnings


def setup_package():
    warnings.filterwarnings('ignore')
